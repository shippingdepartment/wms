<?php
header("Location: content/store/login.php"); /* Redirect browser */
exit();
?>